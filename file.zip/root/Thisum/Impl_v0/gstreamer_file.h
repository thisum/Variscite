void captureImage(int argc, char** argv);

