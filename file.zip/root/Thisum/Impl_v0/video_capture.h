//
// Created by Thisum Buddhika on 5/5/17.
//


void captureImageFromVideo();
