import cv2;
import os;
import numpy;
from time import time;

t = time();
print( str( t))

print "opening camera";
camera = cv2.VideoCapture(1);
print "camera opened";

print "reading image";
retcal, image = camera.read();
print "image read";

print "writing image";
cv2.imwrite(str(time()) + '.jpg',image);
print "image written";

camera.release();
print "camera released";
